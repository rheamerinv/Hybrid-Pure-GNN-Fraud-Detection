import json
from kafka import KafkaConsumer

# -------------------------------
# Kafka Consumer for Check
# -------------------------------
consumer = KafkaConsumer(
    'fraud_scored',
    bootstrap_servers=['localhost:9092'],
    value_deserializer=lambda x: json.loads(x.decode('utf-8')),
    auto_offset_reset='earliest',
    group_id='check_group',
    consumer_timeout_ms=5000  # stop if no messages
)

count = 0
missing_label = 0
missing_score = 0

for message in consumer:
    txn = message.value
    count += 1

    if 'label' not in txn:
        missing_label += 1
    if 'fraud_score' not in txn:
        missing_score += 1

    if count <= 5:
        print(f"Sample transaction #{count}: {txn}")

consumer.close()

print("\n✅ Kafka Check Summary")
print(f"Total messages checked: {count}")
print(f"Messages missing 'label': {missing_label}")
print(f"Messages missing 'fraud_score': {missing_score}")

