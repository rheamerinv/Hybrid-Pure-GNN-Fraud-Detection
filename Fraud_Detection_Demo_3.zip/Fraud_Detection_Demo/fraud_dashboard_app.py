import streamlit as st
import pandas as pd
import plotly.express as px
import json
import threading
import queue
import time
from datetime import datetime
from kafka import KafkaConsumer
from streamlit.runtime.scriptrunner import add_script_run_ctx

import networkx as nx
import matplotlib.pyplot as plt

from sklearn.metrics import precision_score, recall_score, f1_score, precision_recall_curve, auc
from collections import deque, Counter

# -------------------------------
# Streamlit Page Setup
# -------------------------------
st.set_page_config(page_title="Fraud Detection Dashboard", layout="wide")
st.title("🔍 Real-Time Fraud Detection Dashboard")

# -------------------------------
# Session State
# -------------------------------
if 'fraud_data' not in st.session_state:
    st.session_state.fraud_data = []

if 'consumer_running' not in st.session_state:
    st.session_state.consumer_running = False

data_queue = queue.Queue()

# -------------------------------
# Sliding Window for Metrics
# -------------------------------
WINDOW_SIZE = 200
y_true_window = deque(maxlen=WINDOW_SIZE)
y_pred_window = deque(maxlen=WINDOW_SIZE)

# -------------------------------
# Kafka Consumer Thread
# -------------------------------
def kafka_consumer_thread():
    consumer = KafkaConsumer(
        'fraud_scored',
        bootstrap_servers=['localhost:9092'],
        value_deserializer=lambda x: json.loads(x.decode('utf-8')),
        auto_offset_reset='earliest',
        group_id='dashboard_group'
    )
    for message in consumer:
        if not st.session_state.consumer_running:
            break
        data = message.value

        # Record when the transaction was received
        data['timestamp'] = datetime.now()

        data_queue.put(data)


def start_consumer():
    if not st.session_state.consumer_running:
        st.session_state.consumer_running = True
        thread = threading.Thread(target=kafka_consumer_thread, daemon=True)
        add_script_run_ctx(thread)
        thread.start()
        st.success("✅ Started monitoring!")

def update_data():
    while not data_queue.empty():
        try:
            new_data = data_queue.get_nowait()
            st.session_state.fraud_data.append(new_data)
            if len(st.session_state.fraud_data) > 500:
                st.session_state.fraud_data = st.session_state.fraud_data[-500:]
        except queue.Empty:
            break

# -------------------------------
# Controls
# -------------------------------
col1, col2, col3 = st.columns(3)
with col1:
    if st.button("Start Monitoring"):
        start_consumer()
with col2:
    if st.button("Stop Monitoring"):
        st.session_state.consumer_running = False
with col3:
    if st.button("Clear Data"):
        st.session_state.fraud_data = []
        y_true_window.clear()
        y_pred_window.clear()

status = "🟢 Running" if st.session_state.consumer_running else "🔴 Stopped"
st.write(f"**Status:** {status}")

# -------------------------------
# Filters
# -------------------------------
if st.session_state.fraud_data:
    df_all = pd.DataFrame(st.session_state.fraud_data)
    types = list(df_all['type'].unique())
else:
    types = []

selected_type = st.selectbox("Filter by Type", ["All"] + types)
min_amount = st.slider("Minimum Amount", 0, 10_000_000, 0)

def get_filtered_data():
    data = st.session_state.fraud_data
    if selected_type != "All":
        data = [t for t in data if t['type'] == selected_type]
    data = [t for t in data if t['amount'] >= min_amount]
    return data

# -------------------------------
# Placeholders
# -------------------------------
placeholder_table = st.empty()
placeholder_trend = st.empty()
placeholder_ring = st.empty()
placeholder_metrics = st.empty()

# -------------------------------
# Main Dashboard Loop
# -------------------------------

while st.session_state.consumer_running:
    update_data()
    filtered_data = get_filtered_data()

    # -------------------------------
    # Update Metrics
    # -------------------------------
    for txn in filtered_data[-50:]:
        txn['timestamp_predicted'] = datetime.now()

        # Append to session state if not already present
        if txn not in st.session_state.fraud_data:
            st.session_state.fraud_data.append(txn)

        y_true = txn.get('isFraud_label')
        if y_true is None:
            y_true = txn.get('label')
        if y_true is not None:
            y_true_window.append(y_true)
            y_pred_window.append(txn['fraud_score'])

    y_true_list = list(y_true_window)
    y_pred_list = list(y_pred_window)

    if y_true_list:
        # Compute precision-recall curve and dynamic threshold
        precision_curve, recall_curve, thresholds = precision_recall_curve(y_true_list, y_pred_list)
        f1_scores = 2 * (precision_curve * recall_curve) / (precision_curve + recall_curve + 1e-8)
        best_idx = f1_scores.argmax()
        best_threshold = thresholds[best_idx] if best_idx < len(thresholds) else 0.5

        # Apply threshold
        preds_binary = [int(p > best_threshold) for p in y_pred_list]

        # Compute metrics
        f1 = f1_score(y_true_list, preds_binary)
        precision = precision_score(y_true_list, preds_binary)
        recall = recall_score(y_true_list, preds_binary)
        pr_auc = auc(recall_curve, precision_curve)
    else:
        best_threshold = 0.5
        f1 = precision = recall = pr_auc = 0.0

    # -------------------------------
    # Update Metrics
    # -------------------------------
    with placeholder_metrics.container():
        st.subheader("📊 Real-Time Model Metrics")
        col1, col2, col3, col4, col5, col6 = st.columns(6)
        col1.metric("PR-AUC", f"{pr_auc:.4f}")
        col2.metric("F1 Score", f"{f1:.4f}")
        col3.metric("Precision", f"{precision:.4f}")
        col4.metric("Recall", f"{recall:.4f}")
        col5.metric("Threshold", f"{best_threshold:.3f}")

        # -------------------------------
        # Hybrid GNN + Symbolic Metrics
        # -------------------------------
        # Example symbolic rule: High Amount > 500,000

        st.write("Last 10 True Labels:", y_true_list[-10:] if y_true_list else [])
        st.write("Last 10 Predictions:", [round(p, 3) for p in y_pred_list[-10:]] if y_pred_list else [])
        st.write("Label Counts in Window:", Counter(y_true_window))

        # -------------------------------
        # Latency per transaction
        # -------------------------------
        latencies = [
            (txn['timestamp_predicted'] - txn['timestamp']).total_seconds()
            for txn in st.session_state.fraud_data
            if 'timestamp_predicted' in txn and 'timestamp' in txn
        ]
        avg_latency = sum(latencies) / len(latencies) if latencies else 0.0
        st.write(f"Average Latency per Transaction: {avg_latency:.4f} seconds")

        # -------------------------------
        # Queue Throughput
        # -------------------------------
        if 'start_time' not in st.session_state:
            st.session_state.start_time = datetime.now()
        total_time_seconds = (datetime.now() - st.session_state.start_time).total_seconds()
        transactions_per_sec = len(st.session_state.fraud_data) / total_time_seconds if total_time_seconds > 0 else 0.0
        st.write(f"Transactions Processed per Second: {transactions_per_sec:.2f}")

    # -------------------------------
    # Display Latest Transactions Table
    # -------------------------------
    with placeholder_table.container():
        if filtered_data:
            df_display = pd.DataFrame(filtered_data).tail(10)
            st.table(df_display)
        else:
            st.info("No transactions received yet...")

    # -------------------------------
    # Fraud Alerts
    # -------------------------------
    for txn in filtered_data[-5:]:
        if txn['fraud_score'] > best_threshold:
            st.toast(f"⚠️ High Fraud Risk: {txn['type']} ${txn['amount']:.2f}", icon="⚠️")

    # -------------------------------
    # Fraud Score Trend
    # -------------------------------
    if filtered_data:
        df_trend = pd.DataFrame(filtered_data)
        fig = px.line(df_trend, x='timestamp', y='fraud_score', color='type', title="Fraud Score Trend")
        with placeholder_trend.container():
            st.plotly_chart(fig, use_container_width=True)

    # -------------------------------
    # Fraud Rings
    # -------------------------------
    high_risk_txns = [t for t in filtered_data if t['fraud_score'] > best_threshold]
    if high_risk_txns:
        edges = [(t['nameOrig'], t['nameDest']) for t in high_risk_txns[:18]]
        amounts = [t['amount'] for t in high_risk_txns[:18]]
        G = nx.DiGraph()
        G.add_edges_from(edges)
        plt.figure(figsize=(8,8))
        pos = nx.spring_layout(G, k=0.5)
        nx.draw_networkx_nodes(G, pos, node_color='red', node_size=300)
        nx.draw_networkx_edges(G, pos, alpha=0.7)
        nx.draw_networkx_labels(G, pos, font_size=8)
        edge_labels = {edge: f"{amt:.0f}" for edge, amt in zip(edges, amounts)}
        nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels, font_size=6)
        plt.title("Sample Fraud Ring")
        plt.axis('off')
        with placeholder_ring.container():
            st.pyplot(plt)

    # -------------------------------
    # Symbolic Rules
    # -------------------------------
    rules = {
        "High Amount": "amount > 500,000",
        "Rapid Transfer": "multiple transfers in < 1 min",
        "Cash Out after Cash In": "cash_in followed by cash_out within 2 steps"
    }
    st.table(pd.DataFrame(rules.items(), columns=["Rule", "Description"]))

    time.sleep(1)
