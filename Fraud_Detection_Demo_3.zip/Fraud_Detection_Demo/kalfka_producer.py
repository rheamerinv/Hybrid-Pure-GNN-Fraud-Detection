from kafka import KafkaProducer
import pandas as pd, json, time

TOPIC_IN = "paysim_tx"

producer = KafkaProducer(
    bootstrap_servers="localhost:9092",
    value_serializer=lambda v: json.dumps(v).encode("utf-8")
)

if __name__ == "__main__":
    df = pd.read_csv('/Users/rheamerin/Documents/Flask/Fraud_Detection_Demo/data/df_augmented_paysim copy.csv')
    for _, row in df.iterrows():
        event = row.to_dict()
        producer.send(TOPIC_IN, event)
        print("→ sent", {k: event[k] for k in ("step","type","amount","nameOrig","nameDest","isFraud")})
        time.sleep(0.05)  # speed of stream

