import json
import joblib
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.data import Data
from torch_geometric.nn import SAGEConv   # <-- CHANGED: GraphSAGE instead of GAT
from kafka import KafkaConsumer, KafkaProducer
from sklearn.preprocessing import StandardScaler

# ---------- CONFIG ----------
TOPIC_IN = "paysim_tx"
TOPIC_OUT = "fraud_scored"
BOOTSTRAP = "localhost:9092"
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# ---------- MODEL (GraphSAGE) ----------
class EdgeGNN_Symbolic(nn.Module):
    def __init__(self, in_node, in_edge, in_sym, hid=64, sym_dim=8, dropout=0.0):
        super().__init__()
        self.conv1 = SAGEConv(in_node, hid)   # <-- CHANGED
        self.conv2 = SAGEConv(hid, hid)       # <-- CHANGED
        self.sym_enc = nn.Linear(in_sym, sym_dim)
        self.mlp = nn.Sequential(
            nn.Linear(hid * 2 + in_edge + sym_dim, 128),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(128, 1)
        )

    def forward(self, data, edge_sym):
        x = F.relu(self.conv1(data.x, data.edge_index))
        x = F.relu(self.conv2(x, data.edge_index))
        s, d = data.edge_index
        z = torch.cat([x[s], x[d], data.edge_attr, self.sym_enc(edge_sym)], dim=1)
        return self.mlp(z).squeeze(-1)


# ---------- SYMBOLIC RULES ----------
def build_symbolic_row_simple(e) -> pd.DataFrame:
    amt = float(e.get("amount", 0.0))
    typ = e.get("type", "")
    hour = int(e.get("hour", 0))
    day = int(e.get("day", 0))
    dom = int(e.get("day_of_month", 1))
    new_dest = float(e.get("newbalanceDest", 0.0))
    old_dest = float(e.get("oldbalanceDest", 0.0))
    new_orig = float(e.get("newbalanceOrig", 0.0))
    old_orig = float(e.get("oldbalanceOrg", 0.0))

    sym = pd.DataFrame([{
        "Sym_ZeroAmount": int(amt == 0),
        "Sym_AmountInFraudRange": int(63.8 <= amt <= 10_000_000),
        "Sym_ZeroBalanceDestAndAmount": int(new_dest == 0 and old_dest == 0 and amt > 0),
        "Sym_HighAmount": int(amt > 100_000),
        "Sym_VeryHighAmount": int(amt > 500_000),
        "Sym_RiskyType": int(typ in ["TRANSFER", "CASH_OUT"]),
        "Sym_Drain": int(new_orig == 0 and old_orig > 0 and typ in ["TRANSFER", "CASH_OUT"]),
        "Sym_LargeDestJump": int((new_dest - old_dest) > 100_000),
        "Sym_StepBurst": 0,
        "Sym_NightHour": int(0 <= hour <= 6),
        "Sym_WeekendDay": int(day in [5, 6]),
        "Sym_HighFraudDay": int(dom == 31),
        "Sym_LowFraudDay": int(dom == 1)
    }])
    return sym


def rule_conf_row_simple(sym_df: pd.DataFrame) -> float:
    hi = int(sym_df[['Sym_VeryHighAmount', 'Sym_HighAmount', 'Sym_Drain']].any(axis=1).iloc[0]
             or (sym_df['Sym_RiskyType'].iloc[0] == 1 and sym_df['Sym_LargeDestJump'].iloc[0] == 1)
             or sym_df['Sym_HighFraudDay'].iloc[0] == 1
             or (sym_df['Sym_NightHour'].iloc[0] == 1 and sym_df['Sym_RiskyType'].iloc[0] == 1))
    r = 0.0
    r += 0.90 * hi
    r += 0.95 * int(sym_df['Sym_ZeroAmount'].iloc[0] == 1)
    r += 0.60 * int(sym_df['Sym_AmountInFraudRange'].iloc[0] == 1)
    r += 0.49 * int(sym_df['Sym_ZeroBalanceDestAndAmount'].iloc[0] == 1)
    r += 0.30 * int(sym_df['Sym_LowFraudDay'].iloc[0] == 1)
    return float(np.clip(r, 0, 1))


# ---------- LOAD ARTIFACTS ----------
try:
    edge_scalers = joblib.load("artifacts/edge_scalers.pkl")
except FileNotFoundError:
    print("Warning: edge_scalers.pkl not found. Creating default scalers...")
    edge_scalers = {
        "amount": StandardScaler(),
        "step": StandardScaler(),
        "deltaOrg": StandardScaler(),
        "deltaDest": StandardScaler()
    }
    dummy_amounts = np.array([[0], [1000], [10000], [100000], [1000000]])
    dummy_steps = np.array([[1], [100], [500], [1000], [7671]])
    dummy_deltas = np.array([[-100000], [0], [50000], [100000], [500000]])
    edge_scalers["amount"].fit(dummy_amounts)
    edge_scalers["step"].fit(dummy_steps)
    edge_scalers["deltaOrg"].fit(dummy_deltas)
    edge_scalers["deltaDest"].fit(dummy_deltas)
    joblib.dump(edge_scalers, "artifacts/edge_scalers.pkl")

try:
    type_cols = json.load(open("artifacts/type_ohe_cols.json"))
except FileNotFoundError:
    print("Warning: type_ohe_cols.json not found. Using default type columns...")
    type_cols = ["type_CASH_IN", "type_CASH_OUT", "type_DEBIT", "type_PAYMENT", "type_TRANSFER"]
    with open("artifacts/type_ohe_cols.json", "w") as f:
        json.dump(type_cols, f)

# Model parameters
in_node = 2
in_edge = 4 + 1 + len(type_cols)  # 4 numeric + 1 flagged + type_cols
in_sym = 13

# Load model (GraphSAGE weights)
model = EdgeGNN_Symbolic(in_node, in_edge, in_sym).to(DEVICE)
try:
    model.load_state_dict(torch.load("artifacts/sage_symbolic_model.pt", map_location=DEVICE))  # <-- CHANGED filename
    print("Model loaded successfully (GraphSAGE).")
except FileNotFoundError:
    print("Warning: artifacts/sage_symbolic_model.pt not found. Using untrained model...")
model.eval()

# Running degrees for nodes
in_deg, out_deg = {}, {}

# ---------- KAFKA ----------
consumer = KafkaConsumer(
    TOPIC_IN,
    bootstrap_servers=BOOTSTRAP,
    value_deserializer=lambda m: json.loads(m.decode("utf-8")),
    auto_offset_reset='latest',
    group_id='fraud_detection_group'
)

producer = KafkaProducer(
    bootstrap_servers=BOOTSTRAP,
    value_serializer=lambda m: json.dumps(m).encode("utf-8")
)

# ---------- STREAMING LOOP ----------
print(f"Listening on Kafka topic {TOPIC_IN}...")
for msg in consumer:
    try:
        e = msg.value

        # Extract numeric edge features
        amount = float(e.get("amount", 0.0))
        step = int(e.get("step", 0))
        old_balance_org = float(e.get("oldbalanceOrg", 0.0))
        new_balance_orig = float(e.get("newbalanceOrig", 0.0))
        old_balance_dest = float(e.get("oldbalanceDest", 0.0))
        new_balance_dest = float(e.get("newbalanceDest", 0.0))

        deltaOrg = old_balance_org - new_balance_orig
        deltaDest = new_balance_dest - old_balance_dest
        flagged = int(e.get("isFlaggedFraud", 0))

        # Scale numeric features
        amount_scaled = edge_scalers["amount"].transform([[amount]])[0, 0]
        step_scaled = edge_scalers["step"].transform([[step]])[0, 0]
        deltaOrg_scaled = edge_scalers["deltaOrg"].transform([[deltaOrg]])[0, 0]
        deltaDest_scaled = edge_scalers["deltaDest"].transform([[deltaDest]])[0, 0]

        # Create type one-hot encoding
        transaction_type = e.get("type", "")
        type_ohe = [0] * len(type_cols)
        type_key = f"type_{transaction_type}"
        if type_key in type_cols:
            type_ohe[type_cols.index(type_key)] = 1

        # Combine all edge features
        edge_features = [amount_scaled, step_scaled, deltaOrg_scaled, deltaDest_scaled, flagged] + type_ohe
        edge_attr = torch.tensor([edge_features], dtype=torch.float32, device=DEVICE)  # <-- to DEVICE

        # Create node features (degrees)
        src = e.get("nameOrig", "")
        dst = e.get("nameDest", "")
        out_degree = out_deg.get(src, 0)
        in_degree = in_deg.get(dst, 0)

        node_features = [[np.log1p(in_degree), np.log1p(out_degree)]]
        node_x = torch.tensor(node_features, dtype=torch.float32, device=DEVICE)       # <-- to DEVICE

        # Minimal edge_index for single-edge inference (self-loop style)
        edge_index = torch.tensor([[0], [0]], dtype=torch.long, device=DEVICE)         # <-- to DEVICE

        # Create symbolic features and rule confidence
        sym_df = build_symbolic_row_simple(e)
        rule_confidence = rule_conf_row_simple(sym_df)
        edge_sym = torch.from_numpy(sym_df.values.astype(np.float32)).to(DEVICE)       # <-- to DEVICE

        # Create PyG data object
        data = Data(x=node_x, edge_index=edge_index, edge_attr=edge_attr)

        # Model inference
        with torch.no_grad():
            logit = model(data, edge_sym)
            model_prob = torch.sigmoid(logit).detach().cpu().numpy().item()
            fraud_score = 0.8 * model_prob + 0.2 * rule_confidence

        # Update node degrees
        out_deg[src] = out_degree + 1
        in_deg[dst] = in_degree + 1

        # Prepare output
        output = {
            "step": step,
            "type": transaction_type,
            "amount": amount,
            "nameOrig": src,
            "nameDest": dst,
            "model_prob": float(model_prob),
            "rule_conf": float(rule_confidence),
            "fraud_score": float(fraud_score),
            "isFraud_label": int(e.get("isFraud", 0))
        }

        # Send to output topic
        producer.send(TOPIC_OUT, output)

        print("→ scored:", {k: output[k] for k in ("step", "type", "amount", "fraud_score", "isFraud_label")})

    except Exception as ex:
        print(f"Error processing message: {ex}")
        print(f"Message: {e}")
        continue

print("Consumer stopped.")





