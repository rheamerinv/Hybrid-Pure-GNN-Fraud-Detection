import os, json, joblib, numpy as np, pandas as pd, torch, torch.nn as nn, torch.nn.functional as F
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, average_precision_score, precision_recall_curve
from torch_geometric.data import Data
from torch_geometric.nn import SAGEConv   # <-- CHANGED (GraphSAGE instead of GAT)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# ---------- LOAD DATA ----------
df = pd.read_csv('/Users/rheamerin/Documents/Flask/Fraud_Detection_Demo/data/df_augmented_paysim copy.csv')

print(f"Loaded augmented dataset: {df.shape[0]} rows, fraud proportion: {df['isFraud'].mean():.4f}")

# ---------- GRAPH ----------
accounts = pd.Index(pd.unique(pd.concat([df['nameOrig'], df['nameDest']], ignore_index=True)))
acc2id = {a:i for i,a in enumerate(accounts)}
src = df['nameOrig'].map(acc2id).astype(np.int64).values
dst = df['nameDest'].map(acc2id).astype(np.int64).values
edge_index = torch.from_numpy(np.vstack([src,dst]))

# ---------- EDGE FEATURES ----------
type_ohe = pd.get_dummies(df['type'], prefix='type')
edge_feats = pd.DataFrame({
    'amount': df['amount'].astype(float),
    'step': df['step'].astype(int),
    'deltaOrg': (df['oldbalanceOrg'] - df['newbalanceOrig']).astype(float),
    'deltaDest': (df['newbalanceDest'] - df['oldbalanceDest']).astype(float),
    'flagged': df.get('isFlaggedFraud', 0).astype(int),
})
edge_feats = pd.concat([edge_feats, type_ohe], axis=1)

scaler = StandardScaler()
for c in ['amount','step','deltaOrg','deltaDest']:
    edge_feats[c] = scaler.fit_transform(edge_feats[[c]])

edge_attr = torch.from_numpy(edge_feats.values.astype(np.float32))

# ---------- NODE FEATURES ----------
num_nodes = len(accounts)
deg_in  = np.bincount(dst, minlength=num_nodes)
deg_out = np.bincount(src, minlength=num_nodes)
node_x = torch.from_numpy(np.vstack([np.log1p(deg_in), np.log1p(deg_out)]).T.astype(np.float32))

# ---------- LABELS ----------
edge_label = torch.from_numpy(df['isFraud'].astype(int).values)

# ---------- SYMBOLIC ----------
def build_symbolic(df_raw: pd.DataFrame) -> pd.DataFrame:
    sym = pd.DataFrame(index=df_raw.index)
    sym['Sym_ZeroAmount'] = (df_raw['amount'] == 0).astype(int)
    sym['Sym_AmountInFraudRange'] = ((df_raw['amount'] >= 63.8) & (df_raw['amount'] <= 10_000_000)).astype(int)
    sym['Sym_ZeroBalanceDestAndAmount'] = ((df_raw['newbalanceDest']==0) & (df_raw['oldbalanceDest']==0) & (df_raw['amount']>0)).astype(int)
    q95 = df_raw['amount'].quantile(0.95); q99 = df_raw['amount'].quantile(0.99)
    sym['Sym_HighAmount'] = (df_raw['amount'] > q95).astype(int)
    sym['Sym_VeryHighAmount'] = (df_raw['amount'] > q99).astype(int)
    risky = df_raw['type'].isin(['TRANSFER','CASH_OUT']).astype(int)
    sym['Sym_RiskyType'] = risky
    sym['Sym_Drain'] = ((df_raw['newbalanceOrig']==0) & (df_raw['oldbalanceOrg']>0) & risky).astype(int)
    jump = (df_raw['newbalanceDest'] - df_raw['oldbalanceDest'])
    sym['Sym_LargeDestJump'] = (jump > jump.quantile(0.99)).astype(int)
    cnt = df_raw['step'].map(df_raw['step'].value_counts())
    sym['Sym_StepBurst'] = (cnt > cnt.quantile(0.99)).astype(int)
    sym['Sym_NightHour'] = ((df_raw['hour'] >=0) & (df_raw['hour']<=6)).astype(int)
    sym['Sym_WeekendDay'] = df_raw['day'].isin([5,6]).astype(int)
    sym['Sym_HighFraudDay'] = (df_raw['day_of_month']==31).astype(int)
    sym['Sym_LowFraudDay'] = (df_raw['day_of_month']==1).astype(int)
    return sym

def build_rule_conf(sym_df: pd.DataFrame, device: torch.device):
    rule_conf = torch.zeros(len(sym_df), dtype=torch.float32, device=device)
    hi = ((sym_df['Sym_VeryHighAmount']==1)|(sym_df['Sym_HighAmount']==1)|(sym_df['Sym_Drain']==1)|
          ((sym_df['Sym_RiskyType']==1)&(sym_df['Sym_LargeDestJump']==1))|
          (sym_df['Sym_HighFraudDay']==1)|((sym_df['Sym_NightHour']==1)&(sym_df['Sym_RiskyType']==1)))
    hi_zero_amt = (sym_df['Sym_ZeroAmount']==1)
    in_fraud_range = (sym_df['Sym_AmountInFraudRange']==1)
    zero_bal_dest_and_amt = (sym_df['Sym_ZeroBalanceDestAndAmount']==1)
    low_fraud_day = (sym_df['Sym_LowFraudDay']==1)

    rule_conf += 0.90 * torch.tensor(hi.values.astype(np.float32), device=device)
    rule_conf += 0.95 * torch.tensor(hi_zero_amt.values.astype(np.float32), device=device)
    rule_conf += 0.60 * torch.tensor(in_fraud_range.values.astype(np.float32), device=device)
    rule_conf += 0.49 * torch.tensor(zero_bal_dest_and_amt.values.astype(np.float32), device=device)
    rule_conf += 0.30 * torch.tensor(low_fraud_day.values.astype(np.float32), device=device)
    return torch.clamp(rule_conf, 0, 1)

sym_df = build_symbolic(df)
edge_sym = torch.from_numpy(sym_df.values.astype(np.float32)).to(device)
rule_conf = build_rule_conf(sym_df, device)

# ---------- SPLITS ----------
idx = np.arange(len(edge_label))
edge_label_cpu = edge_label.numpy()
tr, te = train_test_split(idx, test_size=0.2, stratify=edge_label_cpu, random_state=42)
tr, va = train_test_split(tr, test_size=0.2, stratify=edge_label_cpu[tr], random_state=42)

train_mask = torch.zeros(len(idx), dtype=torch.bool); train_mask[tr]=True
val_mask   = torch.zeros(len(idx), dtype=torch.bool); val_mask[va]=True
test_mask  = torch.zeros(len(idx), dtype=torch.bool); test_mask[te]=True

edge_label = edge_label.to(device)
train_mask = train_mask.to(device); val_mask=val_mask.to(device); test_mask=test_mask.to(device)

# ---------- LOSS ----------
pos = int(edge_label[train_mask].sum().item())
neg = int(train_mask.sum().item()) - pos
pos_weight = torch.tensor([neg/max(pos,1)], device=device)
bce = nn.BCEWithLogitsLoss(pos_weight=pos_weight)

data = Data(x=node_x.to(device), edge_index=edge_index.to(device), edge_attr=edge_attr.to(device))

# ---------- MODEL (GraphSAGE only) ----------
class EdgeGNN_Symbolic(nn.Module):
    def __init__(self, in_node, in_edge, in_sym, hid=64, sym_dim=8, dropout=0.3):
        super().__init__()
        self.conv1 = SAGEConv(in_node, hid)   # <-- CHANGED
        self.conv2 = SAGEConv(hid, hid)       # <-- CHANGED
        self.sym_enc = nn.Linear(in_sym, sym_dim)
        self.mlp = nn.Sequential(
            nn.Linear(hid*2 + in_edge + sym_dim, 128),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(128, 1)
        )
    def forward(self, data, edge_sym):
        x = F.relu(self.conv1(data.x, data.edge_index))
        x = F.relu(self.conv2(x, data.edge_index))
        s,d = data.edge_index
        z = torch.cat([x[s], x[d], data.edge_attr, self.sym_enc(edge_sym)], dim=1)
        return self.mlp(z).squeeze(-1)

sym_model = EdgeGNN_Symbolic(
    in_node=node_x.size(1),
    in_edge=edge_attr.size(1),
    in_sym=edge_sym.size(1),
    hid=64, sym_dim=8, dropout=0.3
).to(device)

@torch.no_grad()
def eval_logits(logits, mask, y_true):
    probs = torch.sigmoid(logits).detach().cpu().numpy()
    m = mask.detach().cpu().numpy()
    yt = y_true.detach().cpu().numpy()[m]
    pr_auc = average_precision_score(yt, probs[m])
    prec, rec, thr = precision_recall_curve(yt, probs[m])
    f1 = 2*prec*rec/(prec+rec+1e-12)
    bi = f1.argmax()
    threshold = thr[bi-1] if bi>0 else 0.5
    yp = (probs[m]>=threshold).astype(int)
    report = classification_report(yt, yp, digits=4)
    return pr_auc, threshold, report

# ---------- TRAIN ----------
EPOCHS = 5  # keep small for demo
alpha = 0.1
opt = torch.optim.Adam(sym_model.parameters(), lr=1e-3, weight_decay=1e-4)

for e in range(1,EPOCHS+1):
    sym_model.train()
    opt.zero_grad()
    logits = sym_model(data, edge_sym)
    ce = bce(logits[train_mask], edge_label[train_mask].float())
    p = torch.sigmoid(logits)
    rl = torch.mean(torch.abs(p[train_mask]-rule_conf[train_mask]))
    loss = ce + alpha*rl
    loss.backward()
    nn.utils.clip_grad_norm_(sym_model.parameters(),1.0)
    opt.step()

    if e==1 or e%1==0:
        sym_model.eval()
        with torch.no_grad():
            val_logits = sym_model(data, edge_sym)
        pr_auc, thr, report = eval_logits(val_logits, val_mask, edge_label)
        print(f"[SYM] Ep{e:02d} loss={loss.item():.4f} (ce={ce.item():.4f}, rl={rl.item():.4f}) | val PR-AUC={pr_auc:.4f}")

# ---------- SAVE ARTIFACTS ----------
os.makedirs("artifacts", exist_ok=True)
torch.save(sym_model.state_dict(), "artifacts/sage_symbolic_model.pt")   # <-- filename updated
joblib.dump(scaler, "artifacts/edge_scaler.pkl")
json.dump(list(type_ohe.columns), open("artifacts/type_ohe_cols.json","w"))
print("Saved artifacts to ./artifacts")
